
class State:
    def __init__(self, name):
        self.name = name

def context_to_state(context):
    # simple state derivation
    if "goal" in context:
        return State("active")
    return State("idle")
