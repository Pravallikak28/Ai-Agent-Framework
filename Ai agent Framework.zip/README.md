# Antigravity Agent 🚀

A lightweight, intelligent autonomous agent framework powered by Google's Gemini models. This agent uses a dynamic **State-Policy-Skill** architecture to understand context, make decisions, and generate creative content.

## ✨ Features

*   **🧠 LLM-Powered Brain**: integrated with Google's Gemini Flash for fast and creative reasoning.
*   **🔌 Dynamic Policy Routing**: The agent chooses its own skills based on the user's goal—no hardcoded if/else chains.
*   **💾 Contextual Memory**: Remembers conversation history to provide context-aware responses (e.g., "write another one").
*   **🛡️ Robust Design**: Includes automatic retry logic with exponential backoff to handle API rate limits gracefully.
*   **Modular Architecture**: Clean separation of `Agent`, `State`, `Policy`, and `Skills` for easy extensibility.

## 🛠️ Setup

1.  **Clone the repository**:
    ```bash
    git clone https://github.com/yourusername/antigravity_agent.git
    cd antigravity_agent
    ```

2.  **Install dependencies**:
    ```bash
    pip install google-generativeai
    ```

3.  **Set your API Key**:
    You need a Google AI Studio API key.
    ```powershell
    # Windows PowerShell
    $env:GOOGLE_API_KEY = "your_api_key_here"
    ```

## 🚀 Usage

Run the main agent to generate a poem (or edit `main.py` for other goals):

```bash
python main.py
```

Run the memory test to see multi-turn conversation capabilities:

```bash
python test_memory.py
```

## 📂 Project Structure

*   `agent.py`: The core orchestrator managing history and execution loop.
*   `policies.py`: The decision-making layer (LLM-based routing).
*   `skills.py`: The tool belt containing generative capabilities.
*   `states.py`: Context analyzer.
*   `llm_client.py`: Wrapper for Google Generative AI with retry logic.
