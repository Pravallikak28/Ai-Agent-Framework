
from states import context_to_state
from policies import Policy
from skills import common_skills

class Agent:
    def __init__(self):
        self.policy = Policy()
        self.history = []

    async def run(self, context):
        # Inject history into context
        context["history"] = self.history
        
        state = context_to_state(context)
        # Pass context to policy now
        skill_name = await self.policy.get_skill(context, state)
        
        result = "No suitable skill found."
        if skill_name and skill_name in common_skills:
            print(f"Agent decided to use skill: {skill_name}")
            result = await common_skills[skill_name](context)
        
        # Update history
        self.history.append({"context": context, "result": result})
        return result

agent = Agent()
