
from llm_client import LLMClient

llm_client = LLMClient()

async def generate_content(context):
    goal = context.get("goal")
    history = context.get("history", [])
    
    history_str = ""
    if history:
        history_str = f"History of conversation:\n{history}\n"
        
    Prompt = f"""
    You are a helpful assistant.
    {history_str}
    current goal: {goal}
    
    Please generate detailed content for the current goal, using the history if relevant.
    """
    return await llm_client.generate_content(Prompt)

common_skills = {
    "generate_content": generate_content
}
