
import os
import google.generativeai as genai

class LLMClient:
    def __init__(self):
        api_key = os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            raise ValueError("GOOGLE_API_KEY environment variable not set")
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-flash-lite-latest')

    async def generate_content(self, prompt: str) -> str:
        retries = 3
        base_delay = 2
        
        for attempt in range(retries):
            try:
                response = await self.model.generate_content_async(prompt)
                return response.text
            except Exception as e:
                if "429" in str(e) or "ResourceExhausted" in str(e):
                    if attempt < retries - 1:
                        wait_time = base_delay * (2 ** attempt)
                        print(f"Rate limited. Retrying in {wait_time} seconds...")
                        import asyncio
                        await asyncio.sleep(wait_time)
                        continue
                raise e
