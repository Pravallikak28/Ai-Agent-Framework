
from llm_client import LLMClient
from skills import common_skills

class Policy:
    def __init__(self):
        self.llm = LLMClient()

    async def get_skill(self, context, state):
        available_skills = list(common_skills.keys())
        Prompt = f"""
        You are the brain of an autonomous agent.
        Context: {context}
        Current State: {state.name}
        Available Skills: {available_skills}
        
        "generate_content" is a general purpose skill that can write reports, poems, code, or any text.
        Decide which single skill to execute to best serve the user's goal in the context.
        Return ONLY the exact name of the skill from the available list.
        If no skill is applicable, return "None".
        """
        skill_name = await self.llm.generate_content(Prompt)
        print(f"DEBUG: Raw LLM output for skill selection: '{skill_name}'")
        skill_name = skill_name.strip()
        
        # Simple cleanup if LLM adds quotes or extra text
        if skill_name not in available_skills:
            # Fallback or specific cleanup logic
            for s in available_skills:
                if s in skill_name:
                    return s
            return None
            
        return skill_name
