import asyncio
from agent import agent

async def run():
    context = {
        "goal": "Write a poem about coding at midnight"
    }
    result = await agent.run(context)
    print(result)

asyncio.run(run())
    