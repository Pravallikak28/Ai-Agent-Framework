
import asyncio
import sys
from agent import agent

# Force UTF-8 encoding for Windows console
sys.stdout.reconfigure(encoding='utf-8')

async def run():
    print("--- Turn 1: Poem ---")
    context1 = {"goal": "Write a short haiku about Python"}
    result1 = await agent.run(context1)
    print(f"Result 1:\n{result1}")
    
    print("\n--- Turn 2: Follow-up (Testing Memory) ---")
    # asking for "another one" relies on memory to know what "one" means
    context2 = {"goal": "Write another one, but about Rust this time"}
    result2 = await agent.run(context2)
    print(f"Result 2:\n{result2}")

asyncio.run(run())
