
import google.generativeai as genai
import os

api_key = os.environ.get("GOOGLE_API_KEY")
if not api_key:
    print("GOOGLE_API_KEY not set")
    exit(1)

genai.configure(api_key=api_key)

try:
    print("Listing generateContent models with '1.5'...")
    for m in genai.list_models():
        if 'generateContent' in m.supported_generation_methods and '1.5' in m.name:
            print(f"FOUND_MODEL: {m.name}")
except Exception as e:
    print(f"Error listing models: {e}")
